# Example Package

This is a simple package that merge two csv files with same data, by date.