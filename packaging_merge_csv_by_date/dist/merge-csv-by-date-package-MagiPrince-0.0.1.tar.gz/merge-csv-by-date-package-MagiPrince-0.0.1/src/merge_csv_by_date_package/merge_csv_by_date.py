

def my_function():
    print("Ez")